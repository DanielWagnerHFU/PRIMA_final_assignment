namespace V1 {
  export class EnemyBall extends Ball {

    constructor(_position: ƒ.Vector3, _radius: number, _lineSegments: LineSegment[], _balls: Ball[]) {
      super(_position, _radius, _lineSegments, _balls);
    }

    //TODO
  }
}