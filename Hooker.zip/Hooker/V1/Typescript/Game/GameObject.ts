namespace V1 {
  export class GameObject extends ƒ.Node {

    constructor(name: string) {
      super(name);
    }
  }
}